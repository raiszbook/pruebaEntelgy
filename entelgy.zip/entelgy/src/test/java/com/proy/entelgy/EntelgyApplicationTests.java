package com.proy.entelgy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntelgyApplicationTests {

	@Test
	void contextLoads() {
	}

}
